/** Unique JupyterLab plugin identifier. */
export const PLUGIN_ID = 'vre-jupyterlab-extension:plugin';

/** Plugin setting keys used for persisted runtime toggles. */
export const SETTINGS = {
  enabled: 'enabled',
  cellReadonlyDesignEnabled: 'cellReadonlyDesignEnabled'
} as const;

/** Command IDs for user-facing plugin toggles. */
export const COMMANDS = {
  toggleReadonlyDesign: `${PLUGIN_ID}:toggle-readonly-design`,
  toggleExtension: `${PLUGIN_ID}:toggle-extension`
} as const;

/** UI constants used for icon styling hooks in command definitions. */
export const UI = {
  logoIconClass: 'vre-jupyterlab-extension__logoIcon'
} as const;

/** Language-related constants for VRE CodeMirror integration. */
export const LANGUAGE = {
  mime: 'text/x-vre',
  defaultCodeMime: 'text/plain',
  kernelName: 'vre-language',
  extensionName: 'vre-jupyterlab-extension-language-support'
} as const;

/** BEM-style class and metadata constants for execution guard visuals/state. */
export const EXECUTION = {
  metadataKey: 'vre.executed',
  stateMetadataKey: 'vre.executionState',
  executedCellClass: 'vre-jupyterlab-extension__cell--executed',
  executedInputClass: 'vre-jupyterlab-extension__input-editor--executed',
  executedEditorClass: 'vre-jupyterlab-extension__cm-editor--executed'
} as const;
