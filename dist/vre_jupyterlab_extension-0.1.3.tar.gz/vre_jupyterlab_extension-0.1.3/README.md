# vre-jupyterlab-extension

[![CI](https://github.com/officiallygod/vre-jupyterlab-extension/actions/workflows/extension-pr-ci.yml/badge.svg)](https://github.com/officiallygod/vre-jupyterlab-extension/actions/workflows/extension-pr-ci.yml)
[![License](https://img.shields.io/badge/license-BSD--3--Clause-blue.svg)](LICENSE)
[![PyPI](https://img.shields.io/pypi/v/vre-jupyterlab-extension.svg)](https://pypi.org/project/vre-jupyterlab-extension)

A prebuilt JupyterLab 4 extension that provides CodeMirror 6 highlighting for the VRE DSL and a simple execution guard.

Why this package

- No Node tooling required for end users — the wheel embeds the prebuilt labextension assets.
- Installable via pip and ready to use in a JupyterLab environment.

Quick install

```bash
pip install vre-jupyterlab-extension
jupyter lab
```

Developer / Build from source

```bash
cd packages/vre-jupyterlab-extension
npm ci
npm run build
python -m pip install --upgrade build
python -m build --wheel --sdist
python -m pip install dist/vre_jupyterlab_extension-*.whl
```

Release (package-local)

You can run the release flow from inside the package directory. The package provides a helper that:

- prompts for the new semantic version
- updates `package.json`, `setup.cfg`, and `vre_jupyterlab_extension/__init__.py`
- removes build artifacts (`dist`, `build`, `lib`, `labextension`, `*.egg-info`, ...)
- runs `npm ci`, builds frontend assets, and builds a Python wheel and sdist

Usage (from repository root):

```bash
cd packages/vre-jupyterlab-extension
npm run release
# or run directly
python3 ./scripts/release.py
```

Notes:

- The README uses the PyPI badge to show the published version dynamically. Avoid hardcoding the version string in the README so the badge stays authoritative.
- The package-local `release` script is intentionally self-contained and safe to run from the package folder.

Release checklist and publish flow

1. Create a release branch or PR title containing `release` (for example: `release/0.1.4`).
2. The workflow `.github/workflows/release-pr-checklist.yml` will auto-insert a release checklist into the PR description if missing.
3. Complete the checklist items before merge.
4. Merge, create and push a tag like `v0.1.4`.
5. The publish workflow `.github/workflows/extension-publish.yml` publishes to PyPI and GitHub Packages.

Runtime requirements

- `jupyterlab>=4.2,<5`

Notes

- The wheel includes `labextension/` and `install.json`; `setup.py` copies these assets into the wheel during the build step.

Contributing

Please see the repository CONTRIBUTING guidelines and open issues to discuss changes.

License

BSD-3-Clause
